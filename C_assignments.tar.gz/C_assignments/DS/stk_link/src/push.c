#include"stk.h"

stl *push(stk *top)
{
	stk *new = create_node();
	
	if(top == )
}
