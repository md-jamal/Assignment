#include<stdio.h>
#include<stdlib.h>

/*Macro*/

#define MAX 50
#define SIZE 5

/*Function Decarlation*/

int push(int , int * , int *);
int pop(int * , int *);
int opt();
void display(int *, int *);
