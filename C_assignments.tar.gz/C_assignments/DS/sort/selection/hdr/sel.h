#include<stdio.h>
#include<stdlib.h>

#define MAX 5

int selection_sort(int *);

