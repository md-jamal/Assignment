#include<stdio.h>
#include<stdlib.h>

#define MAX 5

int insertion_sort(int *);

