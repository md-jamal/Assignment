#include<stdio.h>
#include<stdlib.h>

#define MAX 5

int bubble_sort(int *);

