#include"list.h"

ssl *add_re(sll *head, sll *new_node)
{
		if(head == NULL){
			head = new_node;
			return head;;
		}
		if(((head->next)->data) >= data){
			new_node->next = head->next;
			head->next = new_node;
			return head;
		}
		if((head->next)->data > data){
			
		}
}
