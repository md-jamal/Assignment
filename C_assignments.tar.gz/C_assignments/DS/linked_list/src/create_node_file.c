/*To create Node*/

#include"list.h"

sll *create_node_file(int data)
{
	sll *tmp_ptr = NULL;
	
	if(NULL == ( tmp_ptr = (sll *)malloc(sizeof(sll)))){
		printf("\nMalloc Is failed...");
	}
	else{
		tmp_ptr->data = data;
		tmp_ptr->next = NULL;
	}
	return tmp_ptr;
}
