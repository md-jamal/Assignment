#include<stdio.h>
#include<stdlib.h>

/*Macro*/
#define SIZE 5


int c_enque(int, int, int, int *);
int c_deque(int, int, int *);
void display(int, int, int *);
