#include<stdio.h>
#include<stdlib.h>

/*Macro Definition*/

#define MAX 50


/*Function Declaration*/

int enqueue(int, int, int, int *);
int dequeue(int, int, int*);
void display(int, int, int*);
