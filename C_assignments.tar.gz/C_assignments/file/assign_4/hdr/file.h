/*Header File Of File_word_count */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX 50
void word_count(char * , FILE *);

