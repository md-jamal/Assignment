/*
	Programe : To count word in file.
*/
#include"file.h"

int main()
{
	FILE *fp = NULL; //File Pointer
	file_write("info.db" , fp ); //Function calling of word Count
	return 0;
}
