
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX 50
void search_string(char * , FILE * , char *);

