#include<stdio.h>

void upper_to_lower(char * , FILE *);

