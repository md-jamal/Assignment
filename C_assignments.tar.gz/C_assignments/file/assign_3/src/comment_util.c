#include"comment.h"

int main()
{
	remove_comment();
	return 0;
}
