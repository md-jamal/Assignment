/*
	Header file of string append...
*/
void snappend (char *, char *,int);
