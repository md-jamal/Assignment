/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/

int strcmp_my(char *, char *);

