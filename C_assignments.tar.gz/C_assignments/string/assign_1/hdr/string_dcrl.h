/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/
#include<stdio.h>                                                               
#include<stdlib.h>                                                              
#define SIZE 50

void strcpy_my(char * , const char *);
