/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/

int str_pal(char *, char * , int);
