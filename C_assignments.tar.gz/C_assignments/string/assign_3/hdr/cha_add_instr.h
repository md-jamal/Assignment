/*
	Return address of given position char address

*/

char * chr_add_instr (char *, char );
