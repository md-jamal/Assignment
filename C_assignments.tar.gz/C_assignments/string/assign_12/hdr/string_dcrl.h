/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/
 
void squeeze(char * , int);
