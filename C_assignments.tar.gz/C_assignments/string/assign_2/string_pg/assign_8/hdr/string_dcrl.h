/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/

size_t strspn_my(const char *,const char *)

