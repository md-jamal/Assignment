/*
	N character copy fronm src to dest
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 50
void stcpy_n_my(char * , char * ,int);
