/*
	Header file of string append...
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 50
void snappend (char *, char *,int);
