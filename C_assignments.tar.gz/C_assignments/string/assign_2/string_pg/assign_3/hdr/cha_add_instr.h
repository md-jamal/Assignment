/*
	Return address of given position char address

*/
#include<stdio.h>
#include<stdlib.h>
#include<stddef.h>
#define SIZE 50 
char * chr_add_instr (char *, char );
