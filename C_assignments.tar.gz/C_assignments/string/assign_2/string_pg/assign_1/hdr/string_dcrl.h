/*
	Header File of Stirng Copy
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 50
void strcpy_my(char * , const char *);
