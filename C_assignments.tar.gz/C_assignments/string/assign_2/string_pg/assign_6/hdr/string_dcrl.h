/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/
#include<stdio.h>
#include<stdlib.h>
#define SIZE 50 
int strcmp_my(char *, char *);

