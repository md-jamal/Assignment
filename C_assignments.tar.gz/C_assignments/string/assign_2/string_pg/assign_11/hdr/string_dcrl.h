/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/

void  str_rev(char *,int);
