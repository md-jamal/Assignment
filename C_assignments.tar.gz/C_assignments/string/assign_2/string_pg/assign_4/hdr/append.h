/*
	Header file of string append...
*/
#include<stdio.h>
#include<stdlib.h>
#include<stddef.h>
#include<string.h>
#define SIZE 50 
void sappend (char *, char *,int n);
