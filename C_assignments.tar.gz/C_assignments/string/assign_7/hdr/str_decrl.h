#include<stdio.h>
#include<stdlib.h>
#define SIZE 50

int case_cmp(char * , char *);
