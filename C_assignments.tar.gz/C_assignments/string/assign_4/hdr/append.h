/*
	Header file of string append...
*/
void sappend (char *, char *);
