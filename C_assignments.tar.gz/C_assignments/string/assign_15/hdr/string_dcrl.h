/*
	Header File of Stirng 
	Author :Pritam Krishna Mali.
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 50
void  insertchar (char *, const char , int , int);
