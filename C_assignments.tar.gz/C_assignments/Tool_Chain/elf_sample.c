#include <stdio.h>
int main ( void ) 
{ 
	int num_1 = 10;
	int num_2 = 20;
	int res = 0;

	res = num_1 + num2;

	printf("Result : %d", res);
	return 0;
}
