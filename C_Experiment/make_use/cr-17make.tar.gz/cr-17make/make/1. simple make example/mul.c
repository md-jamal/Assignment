#include "header.h"

int mul (int num1, int num2) {
//      int result = num1 * num2;
//      return result;
        return (num1 * num2)
}
