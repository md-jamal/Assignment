#include <stdio.h>

int add (int, int);
int sub (int, int);
int mul (int, int);
float div (int, int);

