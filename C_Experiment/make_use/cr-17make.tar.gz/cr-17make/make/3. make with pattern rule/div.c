#include "header.h"

float div (int num1, int num2) {
//      float result = num1 / num2;
//      return result;
      return (num1 / num2);
}
